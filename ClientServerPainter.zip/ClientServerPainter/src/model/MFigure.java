package model;

public class MFigure
{
	public int x = 0;
	public int y = 0;
	public int width = 0;
	public int height = 0;
	public int type = 0;
	public int stroke = 0;
	public int color = 0;
	
}
