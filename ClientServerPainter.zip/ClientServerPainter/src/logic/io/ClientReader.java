package logic.io;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

import com.google.gson.Gson;

import frame.RMFrame;

public class ClientReader extends Thread
{
	DataInputStream read;
	RMFrame mainFrame;
	Gson json = new Gson();
	public ClientReader(Socket sock, RMFrame mainFrame)
	{
		this.mainFrame = mainFrame;
		try
		{
			read = new DataInputStream(sock.getInputStream());
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		start();
	}

	@Override
	public void run()
	{
		while(true)
		{
			try
			{
				String line = read.readUTF();
				
			}
			catch (IOException e)
			{
				stop();
				e.printStackTrace();
			}
		}
	}
}
