package clientserver;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import frame.RMFrame;
import model.MFigure;

public class ClientReader extends Thread
{
	DataInputStream read;
	RMFrame mainFrame;
	Gson json = new Gson();
	public ClientReader(Socket sock, RMFrame mainFrame)
	{
		this.mainFrame = mainFrame;
		try
		{
			read = new DataInputStream(sock.getInputStream());
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		start();
	}

	@Override
	public void run()
	{
		while(true)
		{
			try
			{
				String line = read.readUTF();
				System.out.println(line);
				if(mainFrame.rmp == null)
				{
					System.out.println("�����");
				}
				if(line.equals(""))
				{
					break;
				}
				System.out.println(line);
				mainFrame.rmp.setMemento(json.fromJson(line, new TypeToken<ArrayList<MFigure>>(){}.getType()));
			}
			catch (IOException e)
			{
				stop();
				e.printStackTrace();
			}
		}
	}
}
