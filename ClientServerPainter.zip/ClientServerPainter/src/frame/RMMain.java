package frame;
public class RMMain
{
	public static void main(String[] args)
	{
		new RMFrame();
	}
}
