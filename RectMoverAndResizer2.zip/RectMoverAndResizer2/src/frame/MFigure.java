package frame;

public class MFigure
{
	int x = 0;
	int y = 0;
	int width = 0;
	int height = 0;
	int type = 0;
	int stroke = 0;
	int color = 0;
	
}
