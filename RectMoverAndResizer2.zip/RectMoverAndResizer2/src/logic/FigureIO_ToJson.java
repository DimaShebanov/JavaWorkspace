package logic;

import java.awt.Color;
import java.awt.Rectangle;
import java.util.ArrayList;

import frame.Figure;

public class FigureIO_ToJson
{
	RMCommand rmc;
	
	public FigureIO_ToJson(RMCommand rmCommand)
	{
		rmc = rmCommand;
	}


	public String toJson(ArrayList<Figure> figs)
	{
		String str = "{\"Figures\" : [";
		for (Figure figure : figs)
		{
			str += " {";
			str += "\"x\" : " + figure.r.x + ", ";
			str += "\"y\" : " + figure.r.y + ", ";
			str += "\"width\" : " + figure.r.width + ", ";
			str += "\"height\" : " + figure.r.height + ", ";
			str += "\"stroke\" : " + figure.data.stroke + ", ";
			str += "\"type\" : " + figure.data.type + ", ";
			str += "\"color\" : " + figure.data.col.getRGB();
			str += "},";
		}

		str = str.substring(0, str.length() - 1);
		str += "] }";
		return str;

	}
	
	
	public ArrayList<Figure> fromJson(String src)
	{
		ArrayList<Figure> figs = new ArrayList<>();
		boolean fullRect = false;
		boolean fullData = false;
		
		int x = 0;
		int y = 0;
		int width = 0;
		int height = 0;
		int type = 0;
		int stroke = 0;
		Color col = null;
		
		Rectangle rect = null;
		RMData data = null;
		
		String[] strs = src.split("\\W+");
		
		for (int i = 0; i < strs.length ; i++)
		{
			
			switch (strs[i])
			{
				case "x": x = Integer.parseInt(strs[i + 1]); 									break;
				case "y": y = Integer.parseInt(strs[i + 1]); 									break;
				case "width": width = Integer.parseInt(strs[i + 1]); 							break;
				case "height": height = Integer.parseInt(strs[i + 1]); fullRect = true;			break;
				case "type": type = Integer.parseInt(strs[i + 1]); 								break;
				case "stroke": stroke = Integer.parseInt(strs[i + 1]); 							break;
				case "color": col = new Color(-Integer.parseInt(strs[i + 1])); fullData = true; break;
				default:																		break;
			}			
			
			if(fullRect)
			{
				rect = new Rectangle(x, y, width, height);
				fullRect = false;
			}
			if(fullData)
			{
				data = new RMData(stroke, type, col);
				fullData = false;
			}
			if(rect != null & data != null)
			{
				figs.add(new Figure(rect, data, rmc));
				rect = null;
				data = null;
				System.out.println("yep");
			}
		}
		
		
		return figs;
	}

}
