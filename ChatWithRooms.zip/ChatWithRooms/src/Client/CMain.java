package Client;

public class CMain
{
	public static void main(String[] args)
	{
		new CFrame();
	}
}
