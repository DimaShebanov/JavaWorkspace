import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

public class RMPanel extends JPanel implements MouseListener
{
	Point p = null;
	RMData data = new RMData();

	public RMPanel()
	{
		setLayout(null);
		setBounds(0, 0, 600, 600);
		
		addMouseListener(this);
	}

	@Override
	public void mousePressed(MouseEvent e)
	{
		p = e.getPoint();
	}
	@Override
	public void mouseReleased(MouseEvent e)
	{
		Rectangle r = new Rectangle(p, new Dimension(e.getX()-(int)p.getX(), e.getY()-(int)p.getY()));
		add( new Figure( r, data ) );
		repaint();
	}
	@Override
	public void mouseClicked(MouseEvent arg0){}
	@Override
	public void mouseEntered(MouseEvent arg0){}
	@Override
	public void mouseExited(MouseEvent arg0){}
}
