import java.awt.Color;

public class RMData
{
	int stroke = 1;
	int type = 3;
	Color col = Color.black;

}
